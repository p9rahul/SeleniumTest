package com.Report.Demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo {

	public static void main(String[] args) 
	{
//		DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyy_HH:mm:ss");
//		Date startDateTime = new Date();
//		String startDateTime1 = dateFormat.format(startDateTime);
		String cdate = dateDisplay();
		System.out.println(cdate);

	}
	
	public static String dateDisplay()
	{
		DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyy_HH:mm:ss");
		Date startDateTime = new Date();
		String startDateTime1 = dateFormat.format(startDateTime);	
		return startDateTime1;
		
	}

}
