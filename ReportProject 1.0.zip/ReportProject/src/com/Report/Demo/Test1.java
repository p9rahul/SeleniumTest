package com.Report.Demo;

import java.io.IOException;

public class Test1 extends TestBase
{
	
	public static void main(String [] args) throws IOException
	{		
		System.out.println("Demo");

		updateResult( "Test", "Pass", "Test1");
		updateResult( "Test", "Pass", "Test1");
		updateResult( "Test", "Pass", "Test1");
		updateResult( "Test", "Fail", "Test1");
		updateResult( "Test", "Fail", "Test1");
		updateResult( "Test", "Fail", "Test1");
		updateResult( "Test", "Pass", "Test1");
		updateResult( "Test", "Pass", "Test1");
		updateResult( "Test", "Pass", "Test1");
		updateResult( "Test", "Fail", "Test1");
		updateResult( "Test", "Fail", "Test1");
		updateResult( "Test", "Fail", "Test1");
		
		System.out.println("Demo");
	}

}
